document.addEventListener('DOMContentLoaded', function() {
    var gsc = document.getElementById("gsc");
    var acm = document.getElementById("acm");
    var ieee = document.getElementById("ieee");
    var cur = gsc;
    var activeurl = "http://scholar.google.com/scholar?q=";
    gsc.addEventListener("click", function(){Change(gsc)});
    acm.addEventListener("click", function(){Change(acm)});
    ieee.addEventListener("click", function(){Change(ieee)});
    var button = document.getElementById("search-button");
    button.addEventListener("click", Search);
    function Search(){
        var input = document.getElementById("search-box");
        input = input.value.toString();
        var search_string = input.split(" ").join("+");
        chrome.tabs.create({"url": activeurl+search_string});
    }
    function Change(towebsite){
        if(cur!=towebsite)
        {
            cur.classList.remove("activebut");
            towebsite.classList.add("activebut");
            cur = towebsite;
            var mainimg = document.getElementById("mainimg");
            var settings = document.getElementById("settings");
            var full = document.getElementById("full-screen");
            if (cur==ieee)
            {
                activeurl = "https://ieeexplore.ieee.org/search/searchresult.jsp?queryText=";
                mainimg.setAttribute("src", "ieeelogo.png");
                mainimg.setAttribute("style", "width: 40%");
                settings.setAttribute("href", "https://www.ieee.org/profile/myprofile/myprofile.html");
                full.setAttribute("href", "https://ieeexplore.ieee.org/Xplore/home.jsp");
            }
            else if(cur==acm)
            {
                activeurl = "https://dl.acm.org/results.cfm?query=";
                mainimg.setAttribute("src", "acmlogo.png");
                mainimg.setAttribute("style", "width: 40%");
                settings.setAttribute("href", "https://dl.acm.org/signin.cfm");
                full.setAttribute("href", "https://dl.acm.org/");
            }
            else
            {
                activeurl = "https://scholar.google.com/scholar?q=";
                mainimg.setAttribute("src", "gsclogo.png");
                mainimg.setAttribute("style", "width: 70%");
                settings.setAttribute("href", "https://scholar.google.com/scholar_settings");
                full.setAttribute("href", "https://scholar.google.com");
            }
        }
    }
});